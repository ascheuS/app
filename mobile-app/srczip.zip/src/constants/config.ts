export const API_CONFIG = {
    BASE_URL: 'http://192.168.56.1:8000',
    TIMEOUT: 10000, // 10 segundos
};

export const APP_CONFIG = {
    APP_NAME: 'SIGRA Mobile',
    VERSION: '1.0.0',
};